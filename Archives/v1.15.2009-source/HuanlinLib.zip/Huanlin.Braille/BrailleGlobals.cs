using System;
using System.Collections.Generic;
using System.Text;
using Huanlin.Chinese;
using Huanlin.Helpers;
using Huanlin.Braille.Converters;

namespace Huanlin.Braille
{
    /// <summary>
    /// �@���ܼơC
    /// </summary>
    public class BrailleGlobals
    {        
        static private RemoteImmHelper m_ImmHelper; // �Ω󻷺ݪ���A�H�P�ɾA�Ω�U�����ε{������

        static BrailleGlobals()
        {
            m_ImmHelper = new RemoteImmHelper();            
        }

        static public RemoteImmHelper ImmHelper
        {
            get
            {
                return m_ImmHelper;
            }
        }
    }
}

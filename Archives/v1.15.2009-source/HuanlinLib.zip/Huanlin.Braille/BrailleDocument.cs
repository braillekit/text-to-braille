using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Reflection;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using Huanlin.Text;
using Huanlin.Helpers;

namespace Huanlin.Braille
{
	/// <summary>
	/// �N���@���I�r���C
	/// �`�N�G�s�g�����r���ɡA���n�ۦ��_��A�N�����������q�����e��J�F�_�檺�����ѵ{���ӳB�z�C
	/// �]���{���O�H�@�欰�ഫ���򥻳��A�y�l�̭����޸���������A�Y�ۦ��_��A
	/// �i��|�y���{���L�k�b�@��̭���������k�޸��C
	/// </summary>
    [Serializable]
	public class BrailleDocument
	{
		private List<BrailleLine> m_Lines;
		private int m_CellsPerLine = BrailleConst.DefaultCellsPerLine;
        //private BrailleLine m_Title; // �����D

        [OptionalField]
        private List<BraillePageTitle> m_PageTitles;    // �Ҧ��������D�C

        [NonSerialized]
        private string m_FileName;

        [NonSerialized]
		private BrailleProcessor m_Processor;	// �I�r�ഫ���C

        #region �غc�禡

        public BrailleDocument()
		{
			m_Lines = new List<BrailleLine>();
            m_PageTitles = new List<BraillePageTitle>();
		}

		public BrailleDocument(string filename) 
			: this()
		{
			m_FileName = filename;
		}

		public BrailleDocument(BrailleProcessor processor)
			: this()
		{
			m_Processor = processor;
		}


		public BrailleDocument(string filename, BrailleProcessor processor)
			: this(filename)
		{
			m_Processor = processor;
		}

		public BrailleDocument(BrailleProcessor processer, int cellsPerLine)
			: this(processer)
		{
			m_CellsPerLine = cellsPerLine;
		}

		public BrailleDocument(string filename, BrailleProcessor processor, int cellsPerLine)
			: this(filename, processor)
		{
			m_CellsPerLine = cellsPerLine;
        }

        #endregion

        /// <summary>
		/// ���J�����ഫ���I�r�C
		/// </summary>
		public void LoadAndConvert()
		{
			if (StrHelper.IsEmpty(m_FileName))
				throw new Exception("�ɮצW�٩|�����w!");
			if (m_Processor == null)
				throw new Exception("�b�I�s BrailleDocument.Load ���e�A�Х����w BrailleProcessor�C");

			Encoding enc = Encoding.Default;
			if (FileHelper.IsUTF8Encoded(m_FileName))
			{
				enc = Encoding.UTF8;
			}
			using (StreamReader sr = new StreamReader(m_FileName, enc, true))
			{
				try
				{
					LoadAndConvert(sr);
				}
				finally
				{
					sr.Close();
				}
			}
		}

		public void Convert(string text)
		{
			using (StringReader sr = new StringReader(text))
			{
				try
				{
					LoadAndConvert(sr);
				}
				finally
				{
					sr.Close();
				}
			}
		}

		public void LoadAndConvert(string filename)
		{
			FileName = filename;
			LoadAndConvert();
		}

		public void LoadAndConvert(TextReader reader)
		{
            int lineNumber = 0;

			string line;

			this.Clear();

            m_Processor.InitializeForConvertion();

			while (true)
			{
				line = reader.ReadLine();
				if (line == null)
					break;
                lineNumber++;
				ProcessLine(lineNumber, line);
			}

            m_Processor.FormatDocument(this);   // �_��

            FetchPageTitles();      // �������D�C
		}

		/// <summary>
		/// �q�{�s�������I�r�ɮ׸��J�]�ϧǦC�ơ^���s�� BailleDocument ����C
		/// </summary>
		/// <param name="filename">�ɦW</param>
		/// <returns>�s�� BailleDocument ����</returns>
		public static BrailleDocument Deserialize(string filename)
		{
			if (!File.Exists(filename))
			{
				throw new FileNotFoundException("�ɮפ��s�b: " + filename);
			}

			using (FileStream fs = new FileStream(filename, FileMode.Open))
			{
				BinaryReader br = new BinaryReader(fs);

				int fileVersion = br.ReadInt32();
				int lineCount = br.ReadInt32();
				int reserved1 = br.ReadInt32();
				int reserved2 = br.ReadInt32();

				IFormatter fmter = new BinaryFormatter();
				BrailleDocument brDoc = (BrailleDocument)fmter.Deserialize(fs);

				br.Close();
				return brDoc;
			}
		}

		/// <summary>
		/// �x�s���ɮס]�ǦC�Ʀ��G�i��榡�^�C
		/// </summary>
		/// <param name="filename">�ɦW</param>
		public void Save(string filename)
		{
			this.UpdateTitlesLineIndex();

			using (FileStream fs = new FileStream(filename, FileMode.Create))
			{
				BinaryWriter bw = new BinaryWriter(fs);

				bw.Write(1000);                 // ��󪩥�: 1.0.0.0
				bw.Write(this.LineCount);		// �g�J�C��
				bw.Write(0);                    // �O�d����
				bw.Write(0);                    // �O�d����

				IFormatter fmter = new BinaryFormatter();
				fmter.Serialize(fs, this);

				bw.Flush();
				bw.Close();
			}
		}

		private void ProcessLine(int lineNumber, string line)
		{
			BrailleLine brLine = m_Processor.ConvertLine(lineNumber, line);
            if (brLine != null) 
            {
                AddLine(brLine);
            }
		}

        /// <summary>
        /// �[�J�@�C�C
        /// </summary>
        /// <param name="brLine"></param>
        public void AddLine(BrailleLine brLine)
        {
            m_Lines.Add(brLine);
        }

        public void InsertLines(int index, IEnumerable<BrailleLine> lines)
        {
            m_Lines.InsertRange(index, lines);
        }

        /// <summary>
        /// �������w���C�C�`�N�G�u�������C���ʧ@�A���i�M���C�����e����!!
        /// </summary>
        /// <param name="index"></param>
        public void RemoveLine(int index)
        {
            BrailleLine brLine = m_Lines[index];
            m_Lines.RemoveAt(index);
        }

		public void Clear()
		{
			m_Lines.Clear();

            if (m_PageTitles != null)
            {
                m_PageTitles.Clear();
            }
        }

        public override string ToString()
		{
			StringBuilder sb = new StringBuilder();

			foreach (BrailleLine brLine in m_Lines)
			{
				sb.Append(brLine.ToString());
				sb.Append("\r\n");
			}
			return sb.ToString();
		}

        /// <summary>
        /// �q Lines ���X�����X�����D�A�ñN���D�C�ۤ�󤤲����C
        /// </summary>
        public void FetchPageTitles()
        {
            m_PageTitles.Clear();

            BrailleLine brLine;
            int idx = 0;
            while (idx < m_Lines.Count)
            {
                brLine = m_Lines[idx];
                if (brLine.ContainsTitleTag())
                {
                    BraillePageTitle title = new BraillePageTitle(this, idx);
                    m_PageTitles.Add(title);
                    m_Lines.RemoveAt(idx);
                }
                else 
                {
                    idx++;
                }
            }
        }

        /// <summary>
        /// ��s�Ҧ������D���_�l�C���ޡC
        /// �ϥήɾ��GBrailleDocument �s�ɫe�B�C�L�e�C
        /// </summary>
        public void UpdateTitlesLineIndex()
        {
            if (m_PageTitles == null)
            {
                return;
            }

            BraillePageTitle title;
            int idx = 0;
            while (idx < m_PageTitles.Count)
            {
                title = m_PageTitles[idx];
                if (!title.UpdateLineIndex(this))
                {
                    m_PageTitles.RemoveAt(idx);
                }
                else
                {
                    idx++;
                }
            }
        }

        /// <summary>
        /// �ھڨC�ӭ����D�o�_�l�C���ާ�s������� BrailleLine ����C
        /// �ϥήɾ��GBrailleDocument �q�ɮ׸��J�����ɡC
        /// </summary>
        public void UpdateTitlesLineObject()
        {
            if (m_PageTitles == null) 
            {
                return;
            }

            BraillePageTitle title;
            int idx = 0;
            while (idx < m_PageTitles.Count)
            {
                title = m_PageTitles[idx];
                if (!title.UpdateLineObject(this))
                {
                    m_PageTitles.RemoveAt(idx);
                }
                else
                {
                    idx++;
                }
            }
        }

        /// <summary>
        /// �ھګ��w���C���ާP�_�ӦC�Ҧb��m�������D����A�öǦ^�����D�� BrailleLine ����C
        /// </summary>
        /// <param name="lineIdx"></param>
        /// <returns></returns>
        public BrailleLine GetPageTitle(int lineIdx)
        {
            if (m_PageTitles == null)
            {
                return null;
            }

            if (lineIdx < 0)        // �`�N�G���Τ��W��!! �]���b�C�L�ɡA�ǤJ�� lineIdx ���i��j�󵥩��`�C�ơC
                return null;

            BraillePageTitle title;

            int i = m_PageTitles.Count - 1; // �����q���U���W���
            while (i >= 0)
            {
                title = m_PageTitles[i];
                if (lineIdx >= title.BeginLineIndex)
                {
                    return title.TitleLine;
                }
                i--;
            }
            return null;
        }

		/// <summary>
		/// �Ǧ^�Ҧ������D�� BrailleLine �����C�C
		/// </summary>
		/// <returns></returns>
		public List<BrailleLine> GetPageTitleLines()
		{
			List<BrailleLine> lines = new List<BrailleLine>();
			foreach (BraillePageTitle t in m_PageTitles)
			{
				lines.Add(t.TitleLine);
			}
			return lines;
		}

        #region �ǦC�ƨƥ�

        [OnDeserialized]
        private void OnDeserialized(StreamingContext context)
        {
            if (m_PageTitles == null)
            {
                m_PageTitles = new List<BraillePageTitle>();
            }
            UpdateTitlesLineObject();
        }

        #endregion

        // TODO: Dispose pattern�C�T�O�Ҧ����Ϊ��O���鳣��o����C

        #region �ݩ�

		/// <summary>
		/// ���o�γ]�w BrailleProcessor ����ѦҡC
		/// </summary>
        public BrailleProcessor Processor
        {
            get { return m_Processor; }
            set { m_Processor = value; }
        }

        /// <summary>
        /// ���o�γ]�w�C�C�̤j��ơC
        /// </summary>
        public int CellsPerLine
        {
            get { return m_CellsPerLine; }
            set { m_CellsPerLine = value; }
        }

		/// <summary>
		/// ���o�γ]�w�ɦW�C
		/// </summary>
        public string FileName
        {
            get { return m_FileName; }
            set { m_FileName = value; }
        }

        public List<BrailleLine> Lines
        {
            get { return m_Lines; }
        }

        public BrailleLine this[int index]
        {
            get { return m_Lines[index]; }
        }

		/// <summary>
		/// ���o�`�C�ơC
		/// </summary>
        public int LineCount
        {
            get { return m_Lines.Count; }
        }

        /// <summary>
        /// ���o�r�Ƴ̪��� line�C
        /// </summary>
        public BrailleLine LongestLine
        {
            get
            {
                BrailleLine longestLine = null;
                int maxCount = -1;
                int curCount;
                foreach (BrailleLine brLine in m_Lines)
                {
                    curCount = brLine.WordCount;
                    if (curCount > maxCount)
                    {
                        longestLine = brLine;
                        maxCount = brLine.WordCount;
                    }
                }
                return longestLine;
            }
        }

		/// <summary>
		/// ���o�γ]�w�����D��C�C
		/// </summary>
        public List<BraillePageTitle> PageTitles
        {
            get { return m_PageTitles; }
			set { m_PageTitles = value; }
        }

        #endregion

	}
}

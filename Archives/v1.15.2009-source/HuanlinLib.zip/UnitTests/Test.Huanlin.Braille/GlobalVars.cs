using System;
using System.Collections.Generic;
using System.Text;

namespace Huanlin.Braille.UnitTest
{
    class GlobalVars
    {
        private GlobalVars() { }

        public static string ProjectPath = @"D:\Projects\HuanlinLib\Huanlin.Braille\";
        public static string TestDataPath = @"D:\Projects\HuanlinLib\Huanlin.Braille.UnitTest\TestData\";
        
    }
}

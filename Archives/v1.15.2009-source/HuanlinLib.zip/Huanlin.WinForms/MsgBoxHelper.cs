using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

namespace Huanlin.WinForms
{
	public sealed class MsgBoxHelper
	{
		public static void ShowError(string msg)
		{
			MessageBox.Show(msg, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error);
		}

		public static void ShowInfo(string msg)
		{
			MessageBox.Show(msg, "�T��", MessageBoxButtons.OK, MessageBoxIcon.Information);
		}

		public static void ShowWarning(string msg)
		{
			MessageBox.Show(msg, "ĵ�i", MessageBoxButtons.OK, MessageBoxIcon.Warning);
		}

		public static DialogResult ShowOkCancel(string msg)
		{
			return MessageBox.Show(msg, "�T�{", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
		}

		public static DialogResult ShowOkCancel(string msg, MessageBoxDefaultButton defBtn)
		{
			return MessageBox.Show(msg, "�T�{", MessageBoxButtons.OKCancel, MessageBoxIcon.Question, defBtn); 
		}

		public static DialogResult ShowYesNo(string msg)
		{
			return MessageBox.Show(msg, "�߰�", MessageBoxButtons.YesNo, MessageBoxIcon.Question); 
		}

		public static DialogResult ShowYesNo(string msg, MessageBoxDefaultButton defBtn)
		{
			return MessageBox.Show(msg, "�߰�", MessageBoxButtons.YesNo, MessageBoxIcon.Question, defBtn); 
		}

		public static DialogResult ShowYesNoCancel(string msg)
		{
			return MessageBox.Show(msg, "�߰�", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
		}

		public static DialogResult ShowYesNoCancel(string msg, MessageBoxDefaultButton defBtn)
		{
			return MessageBox.Show(msg, "�߰�", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question, defBtn);
		}

		public static DialogResult ShowRetryCancel(string msg)
		{
			return MessageBox.Show(msg, "�߰�", MessageBoxButtons.RetryCancel, MessageBoxIcon.Question);
		}

		public static DialogResult ShowRetryCancel(string msg, MessageBoxDefaultButton defBtn)
		{
			return MessageBox.Show(msg, "�߰�", MessageBoxButtons.RetryCancel, MessageBoxIcon.Question, defBtn);
		}

		public static DialogResult ShowAbortRetryIgnore(string msg)
		{
			return MessageBox.Show(msg, "�߰�", MessageBoxButtons.AbortRetryIgnore, MessageBoxIcon.Question);
		}

		public static DialogResult ShowAbortRetryIgnore(string msg, MessageBoxDefaultButton defBtn)
		{
			return MessageBox.Show(msg, "�߰�", MessageBoxButtons.AbortRetryIgnore, MessageBoxIcon.Question, defBtn);
		}
	}
}

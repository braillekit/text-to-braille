﻿using System;
using System.Collections.Generic;
using System.Text;
using Huanlin.WinApi;
using Huanlin.WinApi.TextServices;
using Huanlin.TextServices.Chinese;
using Huanlin.TextServices.MsIme;

namespace Huanlin.TextServices
{
    /// <summary>
    /// 輸入法輔助工具。
    /// </summary>
    public static class ImeHelper
    {
        private static MsImeFacade m_MsIme;

        public static readonly bool ZhuyinImeInstalled;		// 注音輸入法是否安裝
        public static readonly bool NewZhuyinImeInstalled;	// 新注音輸入法是否安裝
        public static readonly bool IFELanguageReady;		// 微軟智慧型注音字根是否可用

        static ImeHelper()
        {
            // 判斷注音輸入法和新注音輸入法是否已安裝.
            short[] langIds = TextServicesHelper.GetlangIds();
            if (langIds.Length > 0)
            {
                string[] inputMethods = TextServicesHelper.GetEnabledInputMethods(langIds[0]);
                foreach (string ime in inputMethods)
                {
                    if (ime.EndsWith(" 注音"))
                    {
                        ZhuyinImeInstalled = true;
                    }
                    else if (ime.EndsWith(" 新注音"))
                    {
                        NewZhuyinImeInstalled = true;
                    }
                }
            }

            // 檢查微軟智慧型注音服務是否可用.
            try
            {
                m_MsIme = new MsImeFacade(ImeClass.Taiwan);
                if (m_MsIme != null && m_MsIme.IsReady)
                {
                    IFELanguageReady = true;
                }
            }
            catch
            {
                IFELanguageReady = false;
            }
        }

        /// <summary>
        /// 利用 IFELanguage 取得整串中文字的注音碼。
        /// </summary>
        /// <param name="aChineseText">中文字串。</param>
        /// <returns></returns>
        public static string[] GetBopomofo(string aChineseText)
        {
            if (m_MsIme == null)
            {
                throw new Exception("無法取得注音字根：IFELanguage 服務不存在!");
            }

            string[] bopomofoArray = m_MsIme.GetBopomofo(aChineseText);

            // 調整注音碼，使其長度補滿四個字元.
            for (int i = 0; i < bopomofoArray.Length; i++)
            {
                bopomofoArray[i] = new Zhuyin(bopomofoArray[i]).ToString(true);
            }

            return bopomofoArray;
        }

        /// <summary>
        /// 利用 IFELanguage 取得整串中文字的注音碼，同時根據預先指定的詞庫來修正注音。
        /// </summary>
        /// <param name="aChineseText">中文字串。</param>
        /// <returns></returns>
        public static string[] GetBopomofoWithPhraseTable(string aChineseText)
        {
            string[] bopomofoArray = GetBopomofo(aChineseText);

            // 利用擴充詞庫字根表修正 API 傳回的字根。

            ZhuyinPhraseTable phraseTbl = ZhuyinPhraseTable.GetInstance();
            SortedList<int, ZhuyinPhrase> matchedPhrases = phraseTbl.FindPhrases(aChineseText);
            int srcIndex;
            ZhuyinPhrase phrase;

            // 由於可能會有多次置換字串的動作，因此必須由字串的尾部往前進行置換。
            for (int i = matchedPhrases.Count - 1; i >= 0; i--)
            {
                srcIndex = matchedPhrases.Keys[i];      // 取得片語在輸入字串中的來源索引。
                phrase = matchedPhrases.Values[i];   // 取得代表片語的物件。

                //DebugOut("\r\nimmPhrase.Text=" + immPhrase.Text);

                int j = 0;
                foreach (Zhuyin zy in phrase.ZhuyinList)
                {
                    bopomofoArray[srcIndex] = zy.ToString(true);
                    srcIndex++;
                }
            }
            return bopomofoArray;
        }
    }
}

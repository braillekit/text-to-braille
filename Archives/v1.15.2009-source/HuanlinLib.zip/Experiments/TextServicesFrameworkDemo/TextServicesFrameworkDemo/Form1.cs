﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Huanlin.WinApi.TextServices;
using Huanlin.TextServices;

namespace TextServicesFrameworkDemo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            ImeHelper.InitKbl();

            short[] langIds = TextServicesHelper.GetlangIds();
            if (langIds.Length > 0)
            {
                string[] inputMethods = TextServicesHelper.GetInputMethods(langIds[0]);
                lbxAllIme.Items.AddRange(inputMethods);
            }            
        }

        private void btnGetEnabledIme_Click(object sender, EventArgs e)
        {
            lbxEnabledIme.Items.Clear();

            short[] langIds = TextServicesHelper.GetlangIds();
            if (langIds.Length > 0)
            {
                string[] inputMethods = TextServicesHelper.GetEnabledInputMethods(langIds[0]);
                lbxEnabledIme.Items.AddRange(inputMethods);
            }
        }

        private void btnActivateIme_Click(object sender, EventArgs e)
        {
            if (lbxEnabledIme.SelectedIndex < 0)
            {
                return;
            }
            string imeName = lbxEnabledIme.SelectedItem.ToString();

            short[] langIds = TextServicesHelper.GetlangIds();
            if (langIds.Length > 0)
            {
                if (TextServicesHelper.ActivateInputMethod(langIds[0], imeName))
                {
                    statusBar.Items[0].Text = "輸入法切換成功! " + DateTime.Now.ToString();
                }
                else
                {
                    statusBar.Items[0].Text = "輸入法切換失敗! " + DateTime.Now.ToString();
                }
            }

        }

        private void btnEnableIme_Click(object sender, EventArgs e)
        {
            if (lbxAllIme.SelectedIndex < 0)
            {
                return;
            }

            string imeName = lbxAllIme.SelectedItem.ToString();

            short[] langIds = TextServicesHelper.GetlangIds();
            if (langIds.Length > 0)
            {
                if (TextServicesHelper.EnableInputMethod(langIds[0], imeName, true))
                {
                    statusBar.Items[0].Text = "輸入法啟用成功! " + DateTime.Now.ToString();
                }
                else
                {
                    statusBar.Items[0].Text = "輸入法啟用失敗! " + DateTime.Now.ToString();
                }
            }
        }

        private void btnDisableIme_Click(object sender, EventArgs e)
        {
            if (lbxAllIme.SelectedIndex < 0)
            {
                return;
            }

            string imeName = lbxAllIme.SelectedItem.ToString();

            short[] langIds = TextServicesHelper.GetlangIds();
            if (langIds.Length > 0)
            {
                if (TextServicesHelper.EnableInputMethod(langIds[0], imeName, false))
                {
                    statusBar.Items[0].Text = "輸入法移除成功! " + DateTime.Now.ToString();
                }
                else
                {
                    statusBar.Items[0].Text = "輸入法移除失敗! " + DateTime.Now.ToString();
                }
            }
        }

        private void btnGetPhoneticCode_Click(object sender, EventArgs e)
        {

        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;
using Huanlin.WinApi;
using Huanlin.WinApi.TextServices;
using Huanlin.TextServices.Chinese;
using Huanlin.TextServices.MsIme;

namespace Huanlin.TextServices
{
    /// <summary>
    /// 輸入法輔助工具。
    /// </summary>
    public static class ImeHelper
    {
        private static MsImeFacade m_MsIme;
        private static List<KeyboardLayoutInfo> s_KeyboardLayoutList;

        public static readonly bool ZhuyinImeInstalled;		// 注音輸入法是否安裝
        public static readonly bool NewZhuyinImeInstalled;	// 新注音輸入法是否安裝
        public static readonly bool IFELanguageReady;		// 微軟智慧型注音字根是否可用

        static ImeHelper()
        {
            // 判斷注音輸入法和新注音輸入法是否已安裝.
            short[] langIds = TextServicesHelper.GetlangIds();
            if (langIds.Length > 0)
            {
                string[] inputMethods = TextServicesHelper.GetEnabledInputMethods(langIds[0]);
                foreach (string ime in inputMethods)
                {
                    if (ime.EndsWith(" 注音"))
                    {
                        ZhuyinImeInstalled = true;
                    }
                    else if (ime.EndsWith(" 新注音"))
                    {
                        NewZhuyinImeInstalled = true;
                    }
                }
            }

            // 檢查微軟智慧型注音服務是否可用.
            try
            {
                m_MsIme = new MsImeFacade(ImeClass.Taiwan);
                if (m_MsIme != null && m_MsIme.IsReady)
                {
                    IFELanguageReady = true;
                }
            }
            catch
            {
                IFELanguageReady = false;
            }
        }

        /// <summary>
        /// 利用 IFELanguage 取得整串中文字的注音碼。
        /// </summary>
        /// <param name="aChineseText">中文字串。</param>
        /// <returns></returns>
        public static string[] GetBopomofo(string aChineseText)
        {
            if (m_MsIme == null)
            {
                throw new Exception("無法取得注音字根：IFELanguage 服務不存在!");
            }

            string[] bopomofoArray = m_MsIme.GetBopomofo(aChineseText);

            // 調整注音碼，使其長度補滿四個字元.
            for (int i = 0; i < bopomofoArray.Length; i++)
            {
                bopomofoArray[i] = new Zhuyin(bopomofoArray[i]).ToString(true);
            }

            return bopomofoArray;
        }

        /// <summary>
        /// 利用 IFELanguage 取得整串中文字的注音碼，同時根據預先指定的詞庫來修正注音。
        /// </summary>
        /// <param name="aChineseText">中文字串。</param>
        /// <returns></returns>
        public static string[] GetBopomofoWithPhraseTable(string aChineseText)
        {
            string[] bopomofoArray = GetBopomofo(aChineseText);

            // 利用擴充詞庫字根表修正 API 傳回的字根。

            ZhuyinPhraseTable phraseTbl = ZhuyinPhraseTable.GetInstance();
            SortedList<int, ZhuyinPhrase> matchedPhrases = phraseTbl.FindPhrases(aChineseText);
            int srcIndex;
            ZhuyinPhrase phrase;

            // 由於可能會有多次置換字串的動作，因此必須由字串的尾部往前進行置換。
            for (int i = matchedPhrases.Count - 1; i >= 0; i--)
            {
                srcIndex = matchedPhrases.Keys[i];      // 取得片語在輸入字串中的來源索引。
                phrase = matchedPhrases.Values[i];   // 取得代表片語的物件。

                //DebugOut("\r\nimmPhrase.Text=" + immPhrase.Text);

                int j = 0;
                foreach (Zhuyin zy in phrase.ZhuyinList)
                {
                    bopomofoArray[srcIndex] = zy.ToString(true);
                    srcIndex++;
                }
            }
            return bopomofoArray;
        }

        /// <summary>
        /// 取得指定中文字的所有注音碼。此函式會檢查系統上是否有安裝傳統注音輸入法，
        /// 並利用該輸入法來取得中文字的注音字根。
        /// 注意：新注音只能取得第一組字根，如果是破音字，就必須用傳統注音輸入法才能
        /// 取得完整的字根。
        /// Written by Huan-Lin Tsai. Apr-6-2007. Jul-4-2008.
        /// </summary>
        /// <param name="aChineseText">中文字串。</param>
        /// <returns>注音組字字根陣列。每個元素代表一組注音字根，為長度固定四個字元的字串。</returns>
        /// <remarks>注意：一聲的注音符號字元值為 0x02c9，並不是全形空白。
        /// 如需替換，可以使用 Zhuyin.ReplaceFirstTone 方法。
        /// </remarks>
        public static string[] GetPhoneticCodeList(char aChineseWord)
        {
            //CheckAnyImeInstalled();

            string[] phCodes = new string[0];
            bool phImeFound = false;

            foreach (KeyboardLayoutInfo kli in s_KeyboardLayoutList)
            {
                if (kli.ImeName.Equals("注音"))
                {
                    phImeFound = true;
                    phCodes = GetReverseConversionList(kli.Handle, aChineseWord);
                    if (phCodes.Length > 0)
                        break;
                }
            }

            if (!phImeFound)
            {
                throw new Exception("您的系統沒有安裝傳統注音輸入法!");
            }

            return phCodes;
        }


        const int GCL_REVERSECONVERSION = 0x0002;
        [StructLayout(LayoutKind.Sequential)]
        private class CANDIDATELIST
        {
            public int dwSize;
            public int dwStyle;
            public int dwCount;
            public int dwSelection;
            public int dwPageStart;
            public int dwPageSize;
            public int dwOffset;
        }


        // dialog mode of ImmEscape 
        const int IME_ESC_QUERY_SUPPORT = 0x0003;
        const int IME_ESC_RESERVED_FIRST = 0x0004;
        const int IME_ESC_RESERVED_LAST = 0x07FF;
        const int IME_ESC_PRIVATE_FIRST = 0x0800;
        const int IME_ESC_PRIVATE_LAST = 0x0FFF;
        const int IME_ESC_SEQUENCE_TO_INTERNAL = 0x1001;
        const int IME_ESC_GET_EUDC_DICTIONARY = 0x1003;
        const int IME_ESC_SET_EUDC_DICTIONARY = 0x1004;
        const int IME_ESC_MAX_KEY = 0x1005;
        const int IME_ESC_IME_NAME = 0x1006;
        const int IME_ESC_SYNC_HOTKEY = 0x1007;
        const int IME_ESC_HANJA_MODE = 0x1008;
        const int IME_ESC_AUTOMATA = 0x1009;
        const int IME_ESC_PRIVATE_HOTKEY = 0x100A;

        private const string ImmDll = "Imm32.dll"; 

        [DllImport(ImmDll, EntryPoint = "ImmEscapeW", CharSet = CharSet.Unicode, SetLastError = true)]
        public static extern int ImmEscape(IntPtr aHkl, IntPtr aHimc, int aEscape, IntPtr aData);

        [DllImport(ImmDll, EntryPoint = "ImmGetConversionListW", CharSet = CharSet.Unicode, SetLastError = true)]
        public static extern int ImmGetConversionList(IntPtr hKL, IntPtr hImc, string lpSrc, IntPtr lpDst, int dwBufLen, int uFlag);

        [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true, ExactSpelling = true)]
        public static extern int GetKeyboardLayoutList(int size, [Out, MarshalAs(UnmanagedType.LPArray)] IntPtr[] hkls);

        /// <summary>
        /// 取得一個中文字的所有注音組字字根。注意：傳回的字根可能包含全形空白。
        /// 此方法會使用擴充字根表來修正 API 不足或不正確的注音字根。
        /// </summary>
        /// <param name="aHkl"></param>
        /// <param name="aChineseWord">中文字。</param>
        /// <returns></returns>
        /// <remarks></remarks>
        public static string[] GetReverseConversionList(IntPtr aHkl, char aChineseWord)
        {
            string[] rvList = new string[0];

            if (aHkl == IntPtr.Zero || Char.IsWhiteSpace(aChineseWord))
            {
                return rvList;
            }
            int iMaxKey = ImmEscape(aHkl, IntPtr.Zero, IME_ESC_MAX_KEY, IntPtr.Zero);
            if (iMaxKey <= 0)
            {
                return rvList;
            }

            // 某些其實是破音字，API 卻只傳回一組字根，
            // 因此使用自訂的擴充注音字根表，若有符合者，
            // 就不呼叫 IME API。
/*            
            ImmExtTable immExtTbl = ImmExtTable.GetInstance();
            List<Zhuyin> zyList = immExtTbl[aChineseWord];
            if (zyList != null)
            {
                rvList = new string[zyList.Count];
                for (int i = 0; i < zyList.Count; i++)
                {
                    rvList[i] = zyList[i].ToString(true);
                }
                return rvList;
            }
*/
            // 看看這個輸入法是否支援 Reverse Conversion 功能
            // 同時, 偵測需要多大的空間容納取得的資訊
            IntPtr hImc = IntPtr.Zero;
            CANDIDATELIST list = new CANDIDATELIST();
            string chineseText = aChineseWord.ToString();
            int dwSize = ImmGetConversionList(aHkl, hImc, chineseText, IntPtr.Zero, 0, GCL_REVERSECONVERSION);
            if (dwSize > 0)
            {
                byte[] buf;
                IntPtr bufList = Marshal.AllocHGlobal(dwSize);
                try
                {
                    ImmGetConversionList(aHkl, hImc, chineseText, bufList, dwSize, GCL_REVERSECONVERSION);
                    Marshal.PtrToStructure(bufList, list);
                    buf = new byte[dwSize];
                    Marshal.Copy(bufList, buf, 0, dwSize);
                }
                finally
                {
                    Marshal.FreeHGlobal(bufList);
                }

                int count = list.dwCount;   // 有幾組字根
                if (count < 1)
                {
                    return rvList;  // 沒有組字字根。
                }

                int offset = list.dwOffset;

                // 當傳入的文字是 "＿＿" 時，會發生 offset 大於長度的情形，故需避開。
                if (offset < 0 || buf.Length < offset)
                {
                    return rvList;
                }

                string s = System.Text.Encoding.Unicode.GetString(buf, offset, buf.Length - offset);

                rvList = s.Split(new char[] { '\0' }, count);
                // 把最後一組注音字根尾部的垃圾清掉。
                int i = rvList[count - 1].IndexOf('\0');
                if (i >= 0)
                {
                    rvList[count - 1] = rvList[count - 1].Substring(0, i);
                }

                //rvList.AddRange(compRoots);
                // 注意：不要去除全形空白，以便某些場合判斷結合韻（例如： "　ㄨㄛˇ"）。
            }
            return rvList;
        }

        public static void InitKbl()
        {
            s_KeyboardLayoutList = new List<KeyboardLayoutInfo>();

            const int MaxHkl = 20;

            IntPtr[] hklList = new IntPtr[MaxHkl];
            int cntHkl;
            int i;
            IntPtr imeNamePtr;
            string imeName;

            cntHkl = GetKeyboardLayoutList(hklList.Length, hklList);

            if (cntHkl < 1)
            {
                return;
            }

            imeNamePtr = Marshal.AllocCoTaskMem(256);
            try
            {
                for (i = 0; i < cntHkl; i++)
                {
                    if (ImmEscape(hklList[i], IntPtr.Zero, IME_ESC_IME_NAME, imeNamePtr) == 0)
                    {
                        //continue;
                    }
                    imeName = Marshal.PtrToStringUni(imeNamePtr);

                    KeyboardLayoutInfo kli = new KeyboardLayoutInfo(imeName, hklList[i]);
                    s_KeyboardLayoutList.Add(kli);
                }
            }
            finally
            {
                //Marshal.FreeHGlobal(imeNamePtr);
                Marshal.FreeCoTaskMem(imeNamePtr);
            }

        }
    }

    /// <summary>
    /// 此類別用來儲存某個輸入法的名稱以及 keyboard layout handle。
    /// </summary>
    internal class KeyboardLayoutInfo
    {
        public string ImeName;	// 輸入法名稱
        public IntPtr Handle;	// Keyboard layout handle.

        public KeyboardLayoutInfo(string imeName, IntPtr handle)
        {
            this.ImeName = imeName;
            this.Handle = handle;
        }
    }
}

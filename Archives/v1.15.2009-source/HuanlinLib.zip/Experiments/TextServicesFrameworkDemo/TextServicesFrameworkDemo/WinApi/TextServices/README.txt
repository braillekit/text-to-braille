﻿Microsoft Text Services Framework 工具類別

程式撰寫：蔡煥麟
更新日期：2009-12-13

簡介

    Huanlin.WinApi.TextServices 命名空間包含幾個 Text Services Framework 的
    型別定義。
    
參考資料

  - http://www.cnblogs.com/juejue1984/archive/2009/12/02/1615119.html  
 
 

﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;
using MsImeApi = Huanlin.WinApi.MsIme;

namespace Huanlin.TextServices.MsIme
{
	internal static class MorphResultHelper
	{
        public static string GetOutputString(MsImeApi.MorphResult mr)
		{
			return Marshal.PtrToStringUni(mr.PtrToOutputString, mr.OutputLength);
		}

        public static string[] GetMonoRubyArray(MsImeApi.MorphResult mr)
		{
			if (mr.PtrToMonoRubyPosArray.ToInt32() == 0)
			{
				throw new Exception("Monoruby position array is NULL!");
			}

			List<string> results = new List<string>();

			string output = Marshal.PtrToStringUni(mr.PtrToOutputString, mr.OutputLength);

			int offset = 0;
			int lastIndex = -1;
			int currIndex;
			int totalCount = 0;

			while (totalCount < output.Length) 
			{
				currIndex = Marshal.ReadInt16(mr.PtrToMonoRubyPosArray, offset);
				if (lastIndex >= 0) 
				{
					int length = currIndex - lastIndex;
					results.Add(output.Substring(lastIndex, length));
					totalCount += length;
				}
				lastIndex = currIndex;
				offset += 2;			
			}
			return results.ToArray();
		}
	}
}

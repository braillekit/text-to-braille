﻿namespace TextServicesFrameworkDemo
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnGetEnabledIme = new System.Windows.Forms.Button();
            this.lbxEnabledIme = new System.Windows.Forms.ListBox();
            this.button2 = new System.Windows.Forms.Button();
            this.btnEnableIme = new System.Windows.Forms.Button();
            this.statusBar = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.lbxAllIme = new System.Windows.Forms.ListBox();
            this.btnDisableIme = new System.Windows.Forms.Button();
            this.txtInput = new System.Windows.Forms.TextBox();
            this.btnGetPhoneticCode = new System.Windows.Forms.Button();
            this.lbxPhoneticCode = new System.Windows.Forms.ListBox();
            this.statusBar.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnGetEnabledIme
            // 
            this.btnGetEnabledIme.Location = new System.Drawing.Point(23, 236);
            this.btnGetEnabledIme.Name = "btnGetEnabledIme";
            this.btnGetEnabledIme.Size = new System.Drawing.Size(236, 23);
            this.btnGetEnabledIme.TabIndex = 0;
            this.btnGetEnabledIme.Text = "取得已安裝（啟用）的輸入法";
            this.btnGetEnabledIme.UseVisualStyleBackColor = true;
            this.btnGetEnabledIme.Click += new System.EventHandler(this.btnGetEnabledIme_Click);
            // 
            // lbxEnabledIme
            // 
            this.lbxEnabledIme.FormattingEnabled = true;
            this.lbxEnabledIme.ItemHeight = 12;
            this.lbxEnabledIme.Location = new System.Drawing.Point(23, 265);
            this.lbxEnabledIme.Name = "lbxEnabledIme";
            this.lbxEnabledIme.Size = new System.Drawing.Size(259, 112);
            this.lbxEnabledIme.TabIndex = 1;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(288, 354);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(135, 23);
            this.button2.TabIndex = 2;
            this.button2.Text = "切換至選擇的輸入法";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.btnActivateIme_Click);
            // 
            // btnEnableIme
            // 
            this.btnEnableIme.Location = new System.Drawing.Point(23, 177);
            this.btnEnableIme.Name = "btnEnableIme";
            this.btnEnableIme.Size = new System.Drawing.Size(126, 23);
            this.btnEnableIme.TabIndex = 3;
            this.btnEnableIme.Text = "啟用選擇的輸入法";
            this.btnEnableIme.UseVisualStyleBackColor = true;
            this.btnEnableIme.Click += new System.EventHandler(this.btnEnableIme_Click);
            // 
            // statusBar
            // 
            this.statusBar.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1});
            this.statusBar.Location = new System.Drawing.Point(0, 396);
            this.statusBar.Name = "statusBar";
            this.statusBar.Size = new System.Drawing.Size(517, 22);
            this.statusBar.TabIndex = 5;
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.ForeColor = System.Drawing.Color.Blue;
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(502, 17);
            this.toolStripStatusLabel1.Spring = true;
            this.toolStripStatusLabel1.Text = "狀態列";
            // 
            // lbxAllIme
            // 
            this.lbxAllIme.FormattingEnabled = true;
            this.lbxAllIme.ItemHeight = 12;
            this.lbxAllIme.Location = new System.Drawing.Point(23, 23);
            this.lbxAllIme.Name = "lbxAllIme";
            this.lbxAllIme.Size = new System.Drawing.Size(259, 148);
            this.lbxAllIme.TabIndex = 6;
            // 
            // btnDisableIme
            // 
            this.btnDisableIme.Location = new System.Drawing.Point(156, 177);
            this.btnDisableIme.Name = "btnDisableIme";
            this.btnDisableIme.Size = new System.Drawing.Size(126, 23);
            this.btnDisableIme.TabIndex = 7;
            this.btnDisableIme.Text = "移除選擇的輸入法";
            this.btnDisableIme.UseVisualStyleBackColor = true;
            this.btnDisableIme.Click += new System.EventHandler(this.btnDisableIme_Click);
            // 
            // txtInput
            // 
            this.txtInput.Location = new System.Drawing.Point(323, 23);
            this.txtInput.Name = "txtInput";
            this.txtInput.Size = new System.Drawing.Size(100, 22);
            this.txtInput.TabIndex = 8;
            // 
            // btnGetPhoneticCode
            // 
            this.btnGetPhoneticCode.Location = new System.Drawing.Point(323, 51);
            this.btnGetPhoneticCode.Name = "btnGetPhoneticCode";
            this.btnGetPhoneticCode.Size = new System.Drawing.Size(100, 23);
            this.btnGetPhoneticCode.TabIndex = 9;
            this.btnGetPhoneticCode.Text = "反查注音字根";
            this.btnGetPhoneticCode.UseVisualStyleBackColor = true;
            this.btnGetPhoneticCode.Click += new System.EventHandler(this.btnGetPhoneticCode_Click);
            // 
            // lbxPhoneticCode
            // 
            this.lbxPhoneticCode.FormattingEnabled = true;
            this.lbxPhoneticCode.ItemHeight = 12;
            this.lbxPhoneticCode.Location = new System.Drawing.Point(323, 83);
            this.lbxPhoneticCode.Name = "lbxPhoneticCode";
            this.lbxPhoneticCode.Size = new System.Drawing.Size(120, 88);
            this.lbxPhoneticCode.TabIndex = 10;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(517, 418);
            this.Controls.Add(this.lbxPhoneticCode);
            this.Controls.Add(this.btnGetPhoneticCode);
            this.Controls.Add(this.txtInput);
            this.Controls.Add(this.btnDisableIme);
            this.Controls.Add(this.lbxAllIme);
            this.Controls.Add(this.statusBar);
            this.Controls.Add(this.btnEnableIme);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.lbxEnabledIme);
            this.Controls.Add(this.btnGetEnabledIme);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.statusBar.ResumeLayout(false);
            this.statusBar.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnGetEnabledIme;
        private System.Windows.Forms.ListBox lbxEnabledIme;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button btnEnableIme;
        private System.Windows.Forms.StatusStrip statusBar;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ListBox lbxAllIme;
        private System.Windows.Forms.Button btnDisableIme;
        private System.Windows.Forms.TextBox txtInput;
        private System.Windows.Forms.Button btnGetPhoneticCode;
        private System.Windows.Forms.ListBox lbxPhoneticCode;
    }
}


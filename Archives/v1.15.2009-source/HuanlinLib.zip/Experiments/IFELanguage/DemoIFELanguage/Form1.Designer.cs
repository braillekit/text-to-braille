﻿namespace DemoIFELanguage
{
	partial class Form1
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.btnGetJMorphResult = new System.Windows.Forms.Button();
            this.txtInput = new System.Windows.Forms.TextBox();
            this.txtResult = new System.Windows.Forms.TextBox();
            this.grpCmodes = new System.Windows.Forms.GroupBox();
            this.chkNoInvisibleChar = new System.Windows.Forms.CheckBox();
            this.chkName = new System.Windows.Forms.CheckBox();
            this.chkConversation = new System.Windows.Forms.CheckBox();
            this.chkPhrasePredict = new System.Windows.Forms.CheckBox();
            this.chkAutomatic = new System.Windows.Forms.CheckBox();
            this.chkSingleConvert = new System.Windows.Forms.CheckBox();
            this.chkPlauralClause = new System.Windows.Forms.CheckBox();
            this.chkNone = new System.Windows.Forms.CheckBox();
            this.chkUseNoRevWords = new System.Windows.Forms.CheckBox();
            this.chkBestFirst = new System.Windows.Forms.CheckBox();
            this.chkRoman = new System.Windows.Forms.CheckBox();
            this.chkMergeCand = new System.Windows.Forms.CheckBox();
            this.chkUnknownReading = new System.Windows.Forms.CheckBox();
            this.chkRadical = new System.Windows.Forms.CheckBox();
            this.chkPreConv = new System.Windows.Forms.CheckBox();
            this.chkPinYin = new System.Windows.Forms.CheckBox();
            this.chkHangul = new System.Windows.Forms.CheckBox();
            this.chkBoPoMoFo = new System.Windows.Forms.CheckBox();
            this.chkFullWidthOut = new System.Windows.Forms.CheckBox();
            this.chkHalfWidthOut = new System.Windows.Forms.CheckBox();
            this.chkHiraganaOut = new System.Windows.Forms.CheckBox();
            this.chkKatakanaOut = new System.Windows.Forms.CheckBox();
            this.chkNoPruning = new System.Windows.Forms.CheckBox();
            this.chkMonoRuby = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtCmodeCaps = new System.Windows.Forms.TextBox();
            this.grpMsIme = new System.Windows.Forms.GroupBox();
            this.rdoImeTaiwanBpo = new System.Windows.Forms.RadioButton();
            this.rdoImeTaiwan = new System.Windows.Forms.RadioButton();
            this.rdoImeJapan = new System.Windows.Forms.RadioButton();
            this.rdoImeChina = new System.Windows.Forms.RadioButton();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.grpRequest = new System.Windows.Forms.GroupBox();
            this.rdoReqRev = new System.Windows.Forms.RadioButton();
            this.rdoReqReconv = new System.Windows.Forms.RadioButton();
            this.rdoReqConv = new System.Windows.Forms.RadioButton();
            this.grpCmodes.SuspendLayout();
            this.grpMsIme.SuspendLayout();
            this.grpRequest.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnGetJMorphResult
            // 
            this.btnGetJMorphResult.Location = new System.Drawing.Point(336, 336);
            this.btnGetJMorphResult.Margin = new System.Windows.Forms.Padding(4);
            this.btnGetJMorphResult.Name = "btnGetJMorphResult";
            this.btnGetJMorphResult.Size = new System.Drawing.Size(119, 31);
            this.btnGetJMorphResult.TabIndex = 5;
            this.btnGetJMorphResult.Text = "GetJMorphResult";
            this.btnGetJMorphResult.UseVisualStyleBackColor = true;
            this.btnGetJMorphResult.Click += new System.EventHandler(this.btnGetJMorphResult_Click);
            // 
            // txtInput
            // 
            this.txtInput.Font = new System.Drawing.Font("MingLiU", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtInput.Location = new System.Drawing.Point(82, 340);
            this.txtInput.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtInput.Name = "txtInput";
            this.txtInput.Size = new System.Drawing.Size(246, 23);
            this.txtInput.TabIndex = 4;
            this.txtInput.Text = "便宜又方便得不得了";
            // 
            // txtResult
            // 
            this.txtResult.Font = new System.Drawing.Font("MingLiU", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtResult.Location = new System.Drawing.Point(82, 386);
            this.txtResult.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtResult.Multiline = true;
            this.txtResult.Name = "txtResult";
            this.txtResult.Size = new System.Drawing.Size(373, 75);
            this.txtResult.TabIndex = 2;
            // 
            // grpCmodes
            // 
            this.grpCmodes.Controls.Add(this.chkNoInvisibleChar);
            this.grpCmodes.Controls.Add(this.chkName);
            this.grpCmodes.Controls.Add(this.chkConversation);
            this.grpCmodes.Controls.Add(this.chkPhrasePredict);
            this.grpCmodes.Controls.Add(this.chkAutomatic);
            this.grpCmodes.Controls.Add(this.chkSingleConvert);
            this.grpCmodes.Controls.Add(this.chkPlauralClause);
            this.grpCmodes.Controls.Add(this.chkNone);
            this.grpCmodes.Controls.Add(this.chkUseNoRevWords);
            this.grpCmodes.Controls.Add(this.chkBestFirst);
            this.grpCmodes.Controls.Add(this.chkRoman);
            this.grpCmodes.Controls.Add(this.chkMergeCand);
            this.grpCmodes.Controls.Add(this.chkUnknownReading);
            this.grpCmodes.Controls.Add(this.chkRadical);
            this.grpCmodes.Controls.Add(this.chkPreConv);
            this.grpCmodes.Controls.Add(this.chkPinYin);
            this.grpCmodes.Controls.Add(this.chkHangul);
            this.grpCmodes.Controls.Add(this.chkBoPoMoFo);
            this.grpCmodes.Controls.Add(this.chkFullWidthOut);
            this.grpCmodes.Controls.Add(this.chkHalfWidthOut);
            this.grpCmodes.Controls.Add(this.chkHiraganaOut);
            this.grpCmodes.Controls.Add(this.chkKatakanaOut);
            this.grpCmodes.Controls.Add(this.chkNoPruning);
            this.grpCmodes.Controls.Add(this.chkMonoRuby);
            this.grpCmodes.Location = new System.Drawing.Point(239, 58);
            this.grpCmodes.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.grpCmodes.Name = "grpCmodes";
            this.grpCmodes.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.grpCmodes.Size = new System.Drawing.Size(406, 263);
            this.grpCmodes.TabIndex = 3;
            this.grpCmodes.TabStop = false;
            this.grpCmodes.Text = "CMode";
            // 
            // chkNoInvisibleChar
            // 
            this.chkNoInvisibleChar.AutoSize = true;
            this.chkNoInvisibleChar.Location = new System.Drawing.Point(282, 219);
            this.chkNoInvisibleChar.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chkNoInvisibleChar.Name = "chkNoInvisibleChar";
            this.chkNoInvisibleChar.Size = new System.Drawing.Size(115, 20);
            this.chkNoInvisibleChar.TabIndex = 23;
            this.chkNoInvisibleChar.Tag = "0x40000000";
            this.chkNoInvisibleChar.Text = "NoInvisibleChar";
            this.chkNoInvisibleChar.UseVisualStyleBackColor = true;
            this.chkNoInvisibleChar.CheckStateChanged += new System.EventHandler(this.CmodeChanged);
            // 
            // chkName
            // 
            this.chkName.AutoSize = true;
            this.chkName.Location = new System.Drawing.Point(282, 191);
            this.chkName.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chkName.Name = "chkName";
            this.chkName.Size = new System.Drawing.Size(60, 20);
            this.chkName.TabIndex = 22;
            this.chkName.Tag = "0x1000000";
            this.chkName.Text = "Name";
            this.chkName.UseVisualStyleBackColor = true;
            this.chkName.CheckStateChanged += new System.EventHandler(this.CmodeChanged);
            // 
            // chkConversation
            // 
            this.chkConversation.AutoSize = true;
            this.chkConversation.Location = new System.Drawing.Point(282, 164);
            this.chkConversation.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chkConversation.Name = "chkConversation";
            this.chkConversation.Size = new System.Drawing.Size(101, 20);
            this.chkConversation.TabIndex = 21;
            this.chkConversation.Tag = "0x20000000";
            this.chkConversation.Text = "Conversation";
            this.chkConversation.UseVisualStyleBackColor = true;
            this.chkConversation.CheckStateChanged += new System.EventHandler(this.CmodeChanged);
            // 
            // chkPhrasePredict
            // 
            this.chkPhrasePredict.AutoSize = true;
            this.chkPhrasePredict.Location = new System.Drawing.Point(282, 135);
            this.chkPhrasePredict.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chkPhrasePredict.Name = "chkPhrasePredict";
            this.chkPhrasePredict.Size = new System.Drawing.Size(105, 20);
            this.chkPhrasePredict.TabIndex = 20;
            this.chkPhrasePredict.Tag = "0x1000000";
            this.chkPhrasePredict.Text = "PhrasePredict";
            this.chkPhrasePredict.UseVisualStyleBackColor = true;
            this.chkPhrasePredict.CheckStateChanged += new System.EventHandler(this.CmodeChanged);
            // 
            // chkAutomatic
            // 
            this.chkAutomatic.AutoSize = true;
            this.chkAutomatic.Location = new System.Drawing.Point(282, 108);
            this.chkAutomatic.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chkAutomatic.Name = "chkAutomatic";
            this.chkAutomatic.Size = new System.Drawing.Size(84, 20);
            this.chkAutomatic.TabIndex = 19;
            this.chkAutomatic.Tag = "0x08000000";
            this.chkAutomatic.Text = "Automatic";
            this.chkAutomatic.UseVisualStyleBackColor = true;
            this.chkAutomatic.CheckStateChanged += new System.EventHandler(this.CmodeChanged);
            // 
            // chkSingleConvert
            // 
            this.chkSingleConvert.AutoSize = true;
            this.chkSingleConvert.Location = new System.Drawing.Point(282, 80);
            this.chkSingleConvert.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chkSingleConvert.Name = "chkSingleConvert";
            this.chkSingleConvert.Size = new System.Drawing.Size(106, 20);
            this.chkSingleConvert.TabIndex = 18;
            this.chkSingleConvert.Tag = "0x04000000";
            this.chkSingleConvert.Text = "SingleConvert";
            this.chkSingleConvert.UseVisualStyleBackColor = true;
            this.chkSingleConvert.CheckStateChanged += new System.EventHandler(this.CmodeChanged);
            // 
            // chkPlauralClause
            // 
            this.chkPlauralClause.AutoSize = true;
            this.chkPlauralClause.Location = new System.Drawing.Point(282, 52);
            this.chkPlauralClause.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chkPlauralClause.Name = "chkPlauralClause";
            this.chkPlauralClause.Size = new System.Drawing.Size(104, 20);
            this.chkPlauralClause.TabIndex = 17;
            this.chkPlauralClause.Tag = "0x02000000";
            this.chkPlauralClause.Text = "PlauralClause";
            this.chkPlauralClause.UseVisualStyleBackColor = true;
            this.chkPlauralClause.CheckStateChanged += new System.EventHandler(this.CmodeChanged);
            // 
            // chkNone
            // 
            this.chkNone.AutoSize = true;
            this.chkNone.Location = new System.Drawing.Point(282, 26);
            this.chkNone.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chkNone.Name = "chkNone";
            this.chkNone.Size = new System.Drawing.Size(56, 20);
            this.chkNone.TabIndex = 16;
            this.chkNone.Tag = "0x01000000";
            this.chkNone.Text = "None";
            this.chkNone.UseVisualStyleBackColor = true;
            this.chkNone.CheckStateChanged += new System.EventHandler(this.CmodeChanged);
            // 
            // chkUseNoRevWords
            // 
            this.chkUseNoRevWords.AutoSize = true;
            this.chkUseNoRevWords.Location = new System.Drawing.Point(140, 219);
            this.chkUseNoRevWords.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chkUseNoRevWords.Name = "chkUseNoRevWords";
            this.chkUseNoRevWords.Size = new System.Drawing.Size(121, 20);
            this.chkUseNoRevWords.TabIndex = 15;
            this.chkUseNoRevWords.Tag = "0x00008000";
            this.chkUseNoRevWords.Text = "UseNoRevWords";
            this.chkUseNoRevWords.UseVisualStyleBackColor = true;
            this.chkUseNoRevWords.CheckStateChanged += new System.EventHandler(this.CmodeChanged);
            // 
            // chkBestFirst
            // 
            this.chkBestFirst.AutoSize = true;
            this.chkBestFirst.Location = new System.Drawing.Point(140, 191);
            this.chkBestFirst.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chkBestFirst.Name = "chkBestFirst";
            this.chkBestFirst.Size = new System.Drawing.Size(76, 20);
            this.chkBestFirst.TabIndex = 14;
            this.chkBestFirst.Tag = "0x00004000";
            this.chkBestFirst.Text = "BestFirst";
            this.chkBestFirst.UseVisualStyleBackColor = true;
            this.chkBestFirst.CheckStateChanged += new System.EventHandler(this.CmodeChanged);
            // 
            // chkRoman
            // 
            this.chkRoman.AutoSize = true;
            this.chkRoman.Location = new System.Drawing.Point(140, 164);
            this.chkRoman.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chkRoman.Name = "chkRoman";
            this.chkRoman.Size = new System.Drawing.Size(67, 20);
            this.chkRoman.TabIndex = 13;
            this.chkRoman.Tag = "0x00002000";
            this.chkRoman.Text = "Roman";
            this.chkRoman.UseVisualStyleBackColor = true;
            this.chkRoman.CheckStateChanged += new System.EventHandler(this.CmodeChanged);
            // 
            // chkMergeCand
            // 
            this.chkMergeCand.AutoSize = true;
            this.chkMergeCand.Location = new System.Drawing.Point(140, 135);
            this.chkMergeCand.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chkMergeCand.Name = "chkMergeCand";
            this.chkMergeCand.Size = new System.Drawing.Size(92, 20);
            this.chkMergeCand.TabIndex = 12;
            this.chkMergeCand.Tag = "0x00001000";
            this.chkMergeCand.Text = "MergeCand";
            this.chkMergeCand.UseVisualStyleBackColor = true;
            this.chkMergeCand.CheckStateChanged += new System.EventHandler(this.CmodeChanged);
            // 
            // chkUnknownReading
            // 
            this.chkUnknownReading.AutoSize = true;
            this.chkUnknownReading.Location = new System.Drawing.Point(140, 108);
            this.chkUnknownReading.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chkUnknownReading.Name = "chkUnknownReading";
            this.chkUnknownReading.Size = new System.Drawing.Size(125, 20);
            this.chkUnknownReading.TabIndex = 11;
            this.chkUnknownReading.Tag = "0x00000800";
            this.chkUnknownReading.Text = "UnknownReading";
            this.chkUnknownReading.UseVisualStyleBackColor = true;
            this.chkUnknownReading.CheckStateChanged += new System.EventHandler(this.CmodeChanged);
            // 
            // chkRadical
            // 
            this.chkRadical.AutoSize = true;
            this.chkRadical.Location = new System.Drawing.Point(140, 80);
            this.chkRadical.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chkRadical.Name = "chkRadical";
            this.chkRadical.Size = new System.Drawing.Size(68, 20);
            this.chkRadical.TabIndex = 10;
            this.chkRadical.Tag = "0x00000400";
            this.chkRadical.Text = "Radical";
            this.chkRadical.UseVisualStyleBackColor = true;
            this.chkRadical.CheckStateChanged += new System.EventHandler(this.CmodeChanged);
            // 
            // chkPreConv
            // 
            this.chkPreConv.AutoSize = true;
            this.chkPreConv.Location = new System.Drawing.Point(140, 52);
            this.chkPreConv.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chkPreConv.Name = "chkPreConv";
            this.chkPreConv.Size = new System.Drawing.Size(74, 20);
            this.chkPreConv.TabIndex = 9;
            this.chkPreConv.Tag = "0x00000200";
            this.chkPreConv.Text = "PreConv";
            this.chkPreConv.UseVisualStyleBackColor = true;
            this.chkPreConv.CheckStateChanged += new System.EventHandler(this.CmodeChanged);
            // 
            // chkPinYin
            // 
            this.chkPinYin.AutoSize = true;
            this.chkPinYin.Location = new System.Drawing.Point(140, 26);
            this.chkPinYin.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chkPinYin.Name = "chkPinYin";
            this.chkPinYin.Size = new System.Drawing.Size(61, 20);
            this.chkPinYin.TabIndex = 8;
            this.chkPinYin.Tag = "0x00000100";
            this.chkPinYin.Text = "PinYin";
            this.chkPinYin.UseVisualStyleBackColor = true;
            this.chkPinYin.CheckStateChanged += new System.EventHandler(this.CmodeChanged);
            // 
            // chkHangul
            // 
            this.chkHangul.AutoSize = true;
            this.chkHangul.Location = new System.Drawing.Point(16, 219);
            this.chkHangul.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chkHangul.Name = "chkHangul";
            this.chkHangul.Size = new System.Drawing.Size(66, 20);
            this.chkHangul.TabIndex = 7;
            this.chkHangul.Tag = "0x00000080";
            this.chkHangul.Text = "Hangul";
            this.chkHangul.UseVisualStyleBackColor = true;
            this.chkHangul.CheckStateChanged += new System.EventHandler(this.CmodeChanged);
            // 
            // chkBoPoMoFo
            // 
            this.chkBoPoMoFo.AutoSize = true;
            this.chkBoPoMoFo.Location = new System.Drawing.Point(16, 191);
            this.chkBoPoMoFo.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chkBoPoMoFo.Name = "chkBoPoMoFo";
            this.chkBoPoMoFo.Size = new System.Drawing.Size(86, 20);
            this.chkBoPoMoFo.TabIndex = 6;
            this.chkBoPoMoFo.Tag = "0x00000040";
            this.chkBoPoMoFo.Text = "BoPoMoFo";
            this.chkBoPoMoFo.UseVisualStyleBackColor = true;
            this.chkBoPoMoFo.CheckStateChanged += new System.EventHandler(this.CmodeChanged);
            // 
            // chkFullWidthOut
            // 
            this.chkFullWidthOut.AutoSize = true;
            this.chkFullWidthOut.Location = new System.Drawing.Point(16, 164);
            this.chkFullWidthOut.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chkFullWidthOut.Name = "chkFullWidthOut";
            this.chkFullWidthOut.Size = new System.Drawing.Size(100, 20);
            this.chkFullWidthOut.TabIndex = 5;
            this.chkFullWidthOut.Tag = "0x00000020";
            this.chkFullWidthOut.Text = "FullWidthOut";
            this.chkFullWidthOut.UseVisualStyleBackColor = true;
            this.chkFullWidthOut.CheckStateChanged += new System.EventHandler(this.CmodeChanged);
            // 
            // chkHalfWidthOut
            // 
            this.chkHalfWidthOut.AutoSize = true;
            this.chkHalfWidthOut.Location = new System.Drawing.Point(16, 135);
            this.chkHalfWidthOut.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chkHalfWidthOut.Name = "chkHalfWidthOut";
            this.chkHalfWidthOut.Size = new System.Drawing.Size(102, 20);
            this.chkHalfWidthOut.TabIndex = 4;
            this.chkHalfWidthOut.Tag = "0x00000010";
            this.chkHalfWidthOut.Text = "HalfWidthOut";
            this.chkHalfWidthOut.UseVisualStyleBackColor = true;
            this.chkHalfWidthOut.CheckStateChanged += new System.EventHandler(this.CmodeChanged);
            // 
            // chkHiraganaOut
            // 
            this.chkHiraganaOut.AutoSize = true;
            this.chkHiraganaOut.Location = new System.Drawing.Point(16, 108);
            this.chkHiraganaOut.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chkHiraganaOut.Name = "chkHiraganaOut";
            this.chkHiraganaOut.Size = new System.Drawing.Size(98, 20);
            this.chkHiraganaOut.TabIndex = 3;
            this.chkHiraganaOut.Tag = "0x00000000";
            this.chkHiraganaOut.Text = "HiraganaOut";
            this.chkHiraganaOut.UseVisualStyleBackColor = true;
            this.chkHiraganaOut.CheckStateChanged += new System.EventHandler(this.CmodeChanged);
            // 
            // chkKatakanaOut
            // 
            this.chkKatakanaOut.AutoSize = true;
            this.chkKatakanaOut.Location = new System.Drawing.Point(16, 80);
            this.chkKatakanaOut.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chkKatakanaOut.Name = "chkKatakanaOut";
            this.chkKatakanaOut.Size = new System.Drawing.Size(99, 20);
            this.chkKatakanaOut.TabIndex = 2;
            this.chkKatakanaOut.Tag = "0x00000008";
            this.chkKatakanaOut.Text = "KatakanaOut";
            this.chkKatakanaOut.UseVisualStyleBackColor = true;
            this.chkKatakanaOut.CheckStateChanged += new System.EventHandler(this.CmodeChanged);
            // 
            // chkNoPruning
            // 
            this.chkNoPruning.AutoSize = true;
            this.chkNoPruning.Location = new System.Drawing.Point(16, 52);
            this.chkNoPruning.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chkNoPruning.Name = "chkNoPruning";
            this.chkNoPruning.Size = new System.Drawing.Size(85, 20);
            this.chkNoPruning.TabIndex = 1;
            this.chkNoPruning.Tag = "0x00000004";
            this.chkNoPruning.Text = "NoPruning";
            this.chkNoPruning.UseVisualStyleBackColor = true;
            this.chkNoPruning.CheckStateChanged += new System.EventHandler(this.CmodeChanged);
            // 
            // chkMonoRuby
            // 
            this.chkMonoRuby.AutoSize = true;
            this.chkMonoRuby.Location = new System.Drawing.Point(16, 26);
            this.chkMonoRuby.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chkMonoRuby.Name = "chkMonoRuby";
            this.chkMonoRuby.Size = new System.Drawing.Size(86, 20);
            this.chkMonoRuby.TabIndex = 0;
            this.chkMonoRuby.Tag = "0x00000002";
            this.chkMonoRuby.Text = "MonoRuby";
            this.chkMonoRuby.UseVisualStyleBackColor = true;
            this.chkMonoRuby.CheckStateChanged += new System.EventHandler(this.CmodeChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(16, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(179, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Conversion mode capabilities:";
            // 
            // txtCmodeCaps
            // 
            this.txtCmodeCaps.Enabled = false;
            this.txtCmodeCaps.Location = new System.Drawing.Point(201, 13);
            this.txtCmodeCaps.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtCmodeCaps.Name = "txtCmodeCaps";
            this.txtCmodeCaps.ReadOnly = true;
            this.txtCmodeCaps.Size = new System.Drawing.Size(106, 23);
            this.txtCmodeCaps.TabIndex = 1;
            // 
            // grpMsIme
            // 
            this.grpMsIme.Controls.Add(this.rdoImeTaiwanBpo);
            this.grpMsIme.Controls.Add(this.rdoImeTaiwan);
            this.grpMsIme.Controls.Add(this.rdoImeJapan);
            this.grpMsIme.Controls.Add(this.rdoImeChina);
            this.grpMsIme.Location = new System.Drawing.Point(18, 58);
            this.grpMsIme.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.grpMsIme.Name = "grpMsIme";
            this.grpMsIme.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.grpMsIme.Size = new System.Drawing.Size(192, 132);
            this.grpMsIme.TabIndex = 2;
            this.grpMsIme.TabStop = false;
            this.grpMsIme.Text = "MSIME";
            // 
            // rdoImeTaiwanBpo
            // 
            this.rdoImeTaiwanBpo.AutoSize = true;
            this.rdoImeTaiwanBpo.Location = new System.Drawing.Point(19, 101);
            this.rdoImeTaiwanBpo.Name = "rdoImeTaiwanBpo";
            this.rdoImeTaiwanBpo.Size = new System.Drawing.Size(158, 20);
            this.rdoImeTaiwanBpo.TabIndex = 10;
            this.rdoImeTaiwanBpo.TabStop = true;
            this.rdoImeTaiwanBpo.Text = "MSIME.Taiwan.ImeBpo";
            this.rdoImeTaiwanBpo.UseVisualStyleBackColor = true;
            this.rdoImeTaiwanBpo.CheckedChanged += new System.EventHandler(this.ImeChanged);
            // 
            // rdoImeTaiwan
            // 
            this.rdoImeTaiwan.AutoSize = true;
            this.rdoImeTaiwan.Location = new System.Drawing.Point(19, 77);
            this.rdoImeTaiwan.Name = "rdoImeTaiwan";
            this.rdoImeTaiwan.Size = new System.Drawing.Size(111, 20);
            this.rdoImeTaiwan.TabIndex = 9;
            this.rdoImeTaiwan.TabStop = true;
            this.rdoImeTaiwan.Text = "MSIME.Taiwan";
            this.rdoImeTaiwan.UseVisualStyleBackColor = true;
            this.rdoImeTaiwan.CheckedChanged += new System.EventHandler(this.ImeChanged);
            // 
            // rdoImeJapan
            // 
            this.rdoImeJapan.AutoSize = true;
            this.rdoImeJapan.Location = new System.Drawing.Point(19, 51);
            this.rdoImeJapan.Name = "rdoImeJapan";
            this.rdoImeJapan.Size = new System.Drawing.Size(102, 20);
            this.rdoImeJapan.TabIndex = 8;
            this.rdoImeJapan.TabStop = true;
            this.rdoImeJapan.Text = "MSIME.Japan";
            this.rdoImeJapan.UseVisualStyleBackColor = true;
            this.rdoImeJapan.CheckedChanged += new System.EventHandler(this.ImeChanged);
            // 
            // rdoImeChina
            // 
            this.rdoImeChina.AutoSize = true;
            this.rdoImeChina.Location = new System.Drawing.Point(19, 26);
            this.rdoImeChina.Name = "rdoImeChina";
            this.rdoImeChina.Size = new System.Drawing.Size(101, 20);
            this.rdoImeChina.TabIndex = 7;
            this.rdoImeChina.TabStop = true;
            this.rdoImeChina.Text = "MSIME.China";
            this.rdoImeChina.UseVisualStyleBackColor = true;
            this.rdoImeChina.CheckedChanged += new System.EventHandler(this.ImeChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(25, 343);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(42, 16);
            this.label2.TabIndex = 6;
            this.label2.Text = "Input:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(25, 386);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(51, 16);
            this.label3.TabIndex = 7;
            this.label3.Text = "Output:";
            // 
            // grpRequest
            // 
            this.grpRequest.Controls.Add(this.rdoReqRev);
            this.grpRequest.Controls.Add(this.rdoReqReconv);
            this.grpRequest.Controls.Add(this.rdoReqConv);
            this.grpRequest.Location = new System.Drawing.Point(18, 208);
            this.grpRequest.Name = "grpRequest";
            this.grpRequest.Size = new System.Drawing.Size(192, 113);
            this.grpRequest.TabIndex = 8;
            this.grpRequest.TabStop = false;
            this.grpRequest.Text = "Request";
            // 
            // rdoReqRev
            // 
            this.rdoReqRev.AutoSize = true;
            this.rdoReqRev.Location = new System.Drawing.Point(20, 77);
            this.rdoReqRev.Name = "rdoReqRev";
            this.rdoReqRev.Size = new System.Drawing.Size(131, 20);
            this.rdoReqRev.TabIndex = 12;
            this.rdoReqRev.TabStop = true;
            this.rdoReqRev.Tag = "0x00030000";
            this.rdoReqRev.Text = "FELANG_REQ_REV";
            this.rdoReqRev.UseVisualStyleBackColor = true;
            this.rdoReqRev.CheckedChanged += new System.EventHandler(this.RequestChanged);
            // 
            // rdoReqReconv
            // 
            this.rdoReqReconv.AutoSize = true;
            this.rdoReqReconv.Location = new System.Drawing.Point(20, 51);
            this.rdoReqReconv.Name = "rdoReqReconv";
            this.rdoReqReconv.Size = new System.Drawing.Size(156, 20);
            this.rdoReqReconv.TabIndex = 11;
            this.rdoReqReconv.TabStop = true;
            this.rdoReqReconv.Tag = "0x00020000";
            this.rdoReqReconv.Text = "FELANG_REQ_RECONV";
            this.rdoReqReconv.UseVisualStyleBackColor = true;
            this.rdoReqReconv.CheckedChanged += new System.EventHandler(this.RequestChanged);
            // 
            // rdoReqConv
            // 
            this.rdoReqConv.AutoSize = true;
            this.rdoReqConv.Location = new System.Drawing.Point(20, 27);
            this.rdoReqConv.Name = "rdoReqConv";
            this.rdoReqConv.Size = new System.Drawing.Size(141, 20);
            this.rdoReqConv.TabIndex = 10;
            this.rdoReqConv.TabStop = true;
            this.rdoReqConv.Tag = "0x00010000";
            this.rdoReqConv.Text = "FELANG_REQ_CONV";
            this.rdoReqConv.UseVisualStyleBackColor = true;
            this.rdoReqConv.CheckedChanged += new System.EventHandler(this.RequestChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(671, 491);
            this.Controls.Add(this.grpRequest);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.grpMsIme);
            this.Controls.Add(this.txtCmodeCaps);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.grpCmodes);
            this.Controls.Add(this.txtResult);
            this.Controls.Add(this.txtInput);
            this.Controls.Add(this.btnGetJMorphResult);
            this.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "IFELanguage Demo by Huanlin Tsai.";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.grpCmodes.ResumeLayout(false);
            this.grpCmodes.PerformLayout();
            this.grpMsIme.ResumeLayout(false);
            this.grpMsIme.PerformLayout();
            this.grpRequest.ResumeLayout(false);
            this.grpRequest.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Button btnGetJMorphResult;
		private System.Windows.Forms.TextBox txtInput;
        private System.Windows.Forms.TextBox txtResult;
        private System.Windows.Forms.GroupBox grpCmodes;
        private System.Windows.Forms.CheckBox chkUseNoRevWords;
        private System.Windows.Forms.CheckBox chkBestFirst;
        private System.Windows.Forms.CheckBox chkRoman;
        private System.Windows.Forms.CheckBox chkMergeCand;
        private System.Windows.Forms.CheckBox chkUnknownReading;
        private System.Windows.Forms.CheckBox chkRadical;
        private System.Windows.Forms.CheckBox chkPreConv;
        private System.Windows.Forms.CheckBox chkPinYin;
        private System.Windows.Forms.CheckBox chkHangul;
        private System.Windows.Forms.CheckBox chkBoPoMoFo;
        private System.Windows.Forms.CheckBox chkFullWidthOut;
        private System.Windows.Forms.CheckBox chkHalfWidthOut;
        private System.Windows.Forms.CheckBox chkHiraganaOut;
        private System.Windows.Forms.CheckBox chkNoInvisibleChar;
        private System.Windows.Forms.CheckBox chkName;
        private System.Windows.Forms.CheckBox chkConversation;
        private System.Windows.Forms.CheckBox chkPhrasePredict;
        private System.Windows.Forms.CheckBox chkAutomatic;
        private System.Windows.Forms.CheckBox chkSingleConvert;
        private System.Windows.Forms.CheckBox chkPlauralClause;
        private System.Windows.Forms.CheckBox chkNone;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtCmodeCaps;
        private System.Windows.Forms.CheckBox chkKatakanaOut;
        private System.Windows.Forms.CheckBox chkNoPruning;
        private System.Windows.Forms.CheckBox chkMonoRuby;
        private System.Windows.Forms.GroupBox grpMsIme;
        private System.Windows.Forms.RadioButton rdoImeChina;
        private System.Windows.Forms.RadioButton rdoImeTaiwanBpo;
        private System.Windows.Forms.RadioButton rdoImeTaiwan;
        private System.Windows.Forms.RadioButton rdoImeJapan;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox grpRequest;
        private System.Windows.Forms.RadioButton rdoReqRev;
        private System.Windows.Forms.RadioButton rdoReqReconv;
        private System.Windows.Forms.RadioButton rdoReqConv;
	}
}


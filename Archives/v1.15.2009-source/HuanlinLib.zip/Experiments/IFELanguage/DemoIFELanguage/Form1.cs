﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using Huanlin.WinApi.MsIme;

namespace DemoIFELanguage
{
	public partial class Form1 : Form
	{
        private string imeClassName = "";
        private uint cmode = 0;
        private uint request = 0;        

		public Form1()
		{
			InitializeComponent();
		}

        private void Form1_Load(object sender, EventArgs e)
        {
            rdoImeTaiwan.Checked = true;
            rdoReqRev.Checked = true;
            CmodeChanged(null, EventArgs.Empty);
        }

        private void GetCmodeCapabilities()
        {
            Guid imeGuid;
            int errCode;
            IFELanguage ifeLang = null;

            try
            {
                errCode = WinApi.Ole32.CLSIDFromString(imeClassName, out imeGuid);
                WinApi.WinBase.CheckError(errCode);

                Guid feLangIID = new Guid("019F7152-E6DB-11D0-83C3-00C04FDDB82E");

                IntPtr ppv;

                errCode = WinApi.Ole32.CoCreateInstance(imeGuid, IntPtr.Zero, WinApi.Ole32.CLSCTX_SERVER,
                    feLangIID, out ppv);
                WinApi.WinBase.CheckError(errCode);

                ifeLang = Marshal.GetTypedObjectForIUnknown(ppv, typeof(IFELanguage)) as IFELanguage;

                errCode = ifeLang.Open();
                WinApi.WinBase.CheckError(errCode);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }

            // Get conversion mode capabilities.
            try
            {
                IntPtr capsPtr;
                errCode = ifeLang.GetConversionModeCaps(out capsPtr);
                WinApi.WinBase.CheckError(errCode);

                int caps = capsPtr.ToInt32();
                txtCmodeCaps.Text = "0x" + caps.ToString("X8");
            }
            finally
            {
                ifeLang.Close();
            }
        }

        private void CmodeChanged(object sender, EventArgs e)
        {
            CheckBox chk = sender as CheckBox;
            if (chk != null)
            {
                uint flag = Convert.ToUInt32(chk.Tag.ToString(), 16);
                cmode = cmode ^ flag;
            }
            grpCmodes.Text = "CMode = 0x" + cmode.ToString("X8");
        }

        private void ImeChanged(object sender, EventArgs e)
        {
            RadioButton rdo = sender as RadioButton;
            if (rdo != null)
            {
                if (!imeClassName.Equals(rdo.Text))
                {
                    imeClassName = rdo.Text;
                    GetCmodeCapabilities();
                }
            }
        }

        private void RequestChanged(object sender, EventArgs e)
        {
            RadioButton rdo = sender as RadioButton;
            if (rdo != null)
            {
                request = Convert.ToUInt32(rdo.Tag.ToString(), 16);                
            }
        }


        private void btnGetJMorphResult_Click(object sender, EventArgs e)
        {
            if (txtInput.Text.Trim().Length == 0)
            {
                MessageBox.Show("Please input something!");
                return;
            }

            txtResult.Clear();

            const string IID_IFELanguage = "019F7152-E6DB-11D0-83C3-00C04FDDB82E"; 

            Guid imeGuid;
            int errCode;

            errCode = WinApi.Ole32.CLSIDFromString(imeClassName, out imeGuid);
            WinApi.WinBase.CheckError(errCode);

            Guid feLangIID = new Guid(IID_IFELanguage);

            IntPtr ppv;

            errCode = WinApi.Ole32.CoCreateInstance(imeGuid, IntPtr.Zero, WinApi.Ole32.CLSCTX_SERVER,
                feLangIID, out ppv);
            WinApi.WinBase.CheckError(errCode);

            IFELanguage ifeLang =
                Marshal.GetTypedObjectForIUnknown(ppv, typeof(IFELanguage)) as IFELanguage;

            errCode = ifeLang.Open();
            WinApi.WinBase.CheckError(errCode);

            IntPtr result;
            string input = txtInput.Text;

            IntPtr conversion = IntPtr.Zero;

            try
            {
                errCode = ifeLang.GetJMorphResult(
                    request,
                    cmode,
                    input.Length, input, IntPtr.Zero, out result);
                WinApi.WinBase.CheckError(errCode);
            }
            catch (COMException ex)
            {
                MessageBox.Show(ex.Message + "\r\n" + ex.ErrorCode);
                return;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }

            WinApi.WinBase.CheckError(errCode);

            // 解讀 MORRSLT 結構
            MorphResult morr = (MorphResult) Marshal.PtrToStructure(result, typeof(MorphResult));
            
            /*
            int dwSize = Marshal.ReadInt32(result, 0);  // total size of this block. 
            IntPtr pwchOutput = Marshal.ReadIntPtr(result, 4);  // conversion result string. 
            int cchOutput = Marshal.ReadInt16(result, 8);       // lengh of result string. 2 bytes long.
            string bopomofo = Marshal.PtrToStringUni(pwchOutput, cchOutput); 
            */

            // 讀取輸出字串
            string bopomofo = Marshal.PtrToStringUni(morr.PtrToOutputString, morr.OutputLength); 
            txtResult.AppendText(bopomofo + "\r\n");

            // 讀取其他欄位
            if (morr.ReadingStringLength > 0)
            {
                txtResult.AppendText(Marshal.PtrToStringUni(morr.PtrToReadingString, morr.ReadingStringLength));
                txtResult.AppendText("\r\n");
            }

            WinApi.Ole32.CoTaskMemFree(result);

            ifeLang.Close();
        }
	}
}

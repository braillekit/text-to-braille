﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Huanlin.Chinese;

namespace ImmTest
{
	public partial class Form1 : Form
	{
		public Form1()
		{
			InitializeComponent();
		}

		private void button1_Click(object sender, EventArgs e)
		{
			Text = ImmHelper.GetPhoneticCode("便"); //宜又方便得不得了");
			textBox1.Text = ImmHelper.GetPhoneticCode("便宜又方便得不得了");
		}
	}
}

﻿ImeLib v0.1

Written by Huan-Lin Tsai (http://huan-lin.blogspot.com)

Description

  This library provides a wrapper class for IFELanguage.
  
  Please refer to the source code of the demo project for further information.
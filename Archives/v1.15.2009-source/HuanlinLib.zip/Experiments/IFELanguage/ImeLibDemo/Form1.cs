﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using ImeLib;
using MsIme = Huanlin.WinApi.MsIme;

namespace ImeLibDemo
{
	public partial class Form1 : Form
	{
		public Form1()
		{
			InitializeComponent();
		}

		private void Form1_Load(object sender, EventArgs e)
		{
			cboImeType.Items.AddRange(ImeEngine.ImeClassNames);
			cboImeType.SelectedIndex = (int) ImeClass.Taiwan;
		}

		private void btnGetJMorphResult_Click(object sender, EventArgs e)
		{
			ImeClass imeClass = (ImeClass)cboImeType.SelectedIndex;
			using (ImeEngine ime = new ImeEngine(imeClass)) 
			{
				// Show conversion mode capabilities.
				txtConvModeCaps.Text = ime.ConversionModeCaps;

				MsIme.Req req;
                MsIme.Cmodes cmodes;

				switch (imeClass) 
				{
					case ImeClass.China:
						req = MsIme.Req.Rev;
						cmodes = MsIme.Cmodes.PinYin | MsIme.Cmodes.NoInvisibleChar;
						break;
					case ImeClass.Japan:
						req = MsIme.Req.Rev;
						cmodes = MsIme.Cmodes.HiraganaOut;
						break;
					case ImeClass.Taiwan:
						req = MsIme.Req.Rev;
						cmodes = MsIme.Cmodes.BoPoMoFo;
						break;
					case ImeClass.TaiwanBbo:
						req = MsIme.Req.Rev;
						cmodes = MsIme.Cmodes.BoPoMoFo;
						return;
					default:
						return;
				}
				txtResult.AppendText(cboImeType.Text + ": " +
					ime.GetJMorphResult(txtInput.Text, req, cmodes) + Environment.NewLine);
			}			
		}

		private void btnGetBopomofo_Click(object sender, EventArgs e)
		{
			using (ImeEngine ime = new ImeEngine(ImeClass.Taiwan))
			{
				txtResult.AppendText("MSIME.Taiwan: " +
					ime.GetBopomofo(txtInput.Text) + Environment.NewLine);
			}			

		}

		private void btnGetPinYin_Click(object sender, EventArgs e)
		{
			using (ImeEngine ime = new ImeEngine(ImeClass.China))
			{
				txtResult.AppendText("MSIME.China: " + 
					ime.GetPinYin(txtInput.Text) + Environment.NewLine);
			}			
		}
	}
}

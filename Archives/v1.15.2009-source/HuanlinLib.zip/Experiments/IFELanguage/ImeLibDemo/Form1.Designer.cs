﻿namespace ImeLibDemo
{
	partial class Form1
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.label1 = new System.Windows.Forms.Label();
			this.cboImeType = new System.Windows.Forms.ComboBox();
			this.label2 = new System.Windows.Forms.Label();
			this.txtInput = new System.Windows.Forms.TextBox();
			this.label3 = new System.Windows.Forms.Label();
			this.btnGetJMorphResult = new System.Windows.Forms.Button();
			this.btnGetBopomofo = new System.Windows.Forms.Button();
			this.txtResult = new System.Windows.Forms.TextBox();
			this.btnGetPinYin = new System.Windows.Forms.Button();
			this.label4 = new System.Windows.Forms.Label();
			this.txtConvModeCaps = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(33, 27);
			this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(62, 15);
			this.label1.TabIndex = 0;
			this.label1.Text = "Ime Type";
			// 
			// cboImeType
			// 
			this.cboImeType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cboImeType.FormattingEnabled = true;
			this.cboImeType.Location = new System.Drawing.Point(102, 24);
			this.cboImeType.Name = "cboImeType";
			this.cboImeType.Size = new System.Drawing.Size(222, 23);
			this.cboImeType.TabIndex = 1;
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(32, 89);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(62, 15);
			this.label2.TabIndex = 2;
			this.label2.Text = "Input text";
			// 
			// txtInput
			// 
			this.txtInput.Location = new System.Drawing.Point(101, 86);
			this.txtInput.Name = "txtInput";
			this.txtInput.Size = new System.Drawing.Size(373, 25);
			this.txtInput.TabIndex = 3;
			this.txtInput.Text = "便宜又方便得不得了";
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(33, 178);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(42, 15);
			this.label3.TabIndex = 4;
			this.label3.Text = "Result";
			// 
			// btnGetJMorphResult
			// 
			this.btnGetJMorphResult.Location = new System.Drawing.Point(102, 126);
			this.btnGetJMorphResult.Name = "btnGetJMorphResult";
			this.btnGetJMorphResult.Size = new System.Drawing.Size(139, 32);
			this.btnGetJMorphResult.TabIndex = 5;
			this.btnGetJMorphResult.Text = "GetJMorphResult";
			this.btnGetJMorphResult.UseVisualStyleBackColor = true;
			this.btnGetJMorphResult.Click += new System.EventHandler(this.btnGetJMorphResult_Click);
			// 
			// btnGetBopomofo
			// 
			this.btnGetBopomofo.Location = new System.Drawing.Point(247, 126);
			this.btnGetBopomofo.Name = "btnGetBopomofo";
			this.btnGetBopomofo.Size = new System.Drawing.Size(111, 32);
			this.btnGetBopomofo.TabIndex = 6;
			this.btnGetBopomofo.Text = "GetBopomofo";
			this.btnGetBopomofo.UseVisualStyleBackColor = true;
			this.btnGetBopomofo.Click += new System.EventHandler(this.btnGetBopomofo_Click);
			// 
			// txtResult
			// 
			this.txtResult.Location = new System.Drawing.Point(101, 175);
			this.txtResult.Multiline = true;
			this.txtResult.Name = "txtResult";
			this.txtResult.ReadOnly = true;
			this.txtResult.ScrollBars = System.Windows.Forms.ScrollBars.Both;
			this.txtResult.Size = new System.Drawing.Size(549, 120);
			this.txtResult.TabIndex = 7;
			// 
			// btnGetPinYin
			// 
			this.btnGetPinYin.Location = new System.Drawing.Point(364, 126);
			this.btnGetPinYin.Name = "btnGetPinYin";
			this.btnGetPinYin.Size = new System.Drawing.Size(111, 32);
			this.btnGetPinYin.TabIndex = 8;
			this.btnGetPinYin.Text = "GetPinYin";
			this.btnGetPinYin.UseVisualStyleBackColor = true;
			this.btnGetPinYin.Click += new System.EventHandler(this.btnGetPinYin_Click);
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(33, 60);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(105, 15);
			this.label4.TabIndex = 9;
			this.label4.Text = "ConvModeCaps: ";
			// 
			// txtConvModeCaps
			// 
			this.txtConvModeCaps.AutoSize = true;
			this.txtConvModeCaps.Location = new System.Drawing.Point(136, 60);
			this.txtConvModeCaps.Name = "txtConvModeCaps";
			this.txtConvModeCaps.Size = new System.Drawing.Size(31, 15);
			this.txtConvModeCaps.TabIndex = 10;
			this.txtConvModeCaps.Text = "N/A";
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(678, 336);
			this.Controls.Add(this.txtConvModeCaps);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.btnGetPinYin);
			this.Controls.Add(this.txtResult);
			this.Controls.Add(this.btnGetBopomofo);
			this.Controls.Add(this.btnGetJMorphResult);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.txtInput);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.cboImeType);
			this.Controls.Add(this.label1);
			this.Font = new System.Drawing.Font("PMingLiU", 11F);
			this.Margin = new System.Windows.Forms.Padding(4);
			this.Name = "Form1";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "ImeLibDemo by Huan-Lin Tsai";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.ComboBox cboImeType;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.TextBox txtInput;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Button btnGetJMorphResult;
		private System.Windows.Forms.Button btnGetBopomofo;
		private System.Windows.Forms.TextBox txtResult;
		private System.Windows.Forms.Button btnGetPinYin;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label txtConvModeCaps;
	}
}


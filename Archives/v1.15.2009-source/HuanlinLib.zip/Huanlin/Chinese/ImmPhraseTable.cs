﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using System.IO;
using System.Reflection;
using System.Text.RegularExpressions;
using Huanlin.Helpers;

namespace Huanlin.Chinese
{
    /// <summary>
    /// 找到的片語資訊。
    /// </summary>
    public sealed class ImmPhrase
    {
        public string Text;             // 片語文字。
        public List<Zhuyin> ZhuyinList; // 片語的注音字根串列。

        public ImmPhrase(string text, List<Zhuyin> zyList)
        {
            this.Text = text;
            this.ZhuyinList = zyList;
        }
    }

    /// <summary>
    /// 注音詞庫檔。用來修正新注音智慧型註音詞庫不正確的字根，例如：
    /// 「什麼」：新注音傳回「ㄕㄜˊ ㄇㄛ˙」，但應該是「ㄕㄜˊ ㄇㄜ˙」。
    /// 「給付」：新注音傳回「ㄍㄟˇ ㄈㄨˋ」，但應該是「ㄐㄧˇ ㄈㄨˋ」。
    /// </summary>
    public sealed class ImmPhraseTable
    {
        private const string ImmPhraseTblResName = "Huanlin.Chinese.ImmPhrase.tbl";
        private static ImmPhraseTable m_ImmPhraseTbl = null;

        private Hashtable m_Table;  // 中文字與注音字根對照表，每一筆代表一個中文字的所有注音字根。

        private ImmPhraseTable()
        {
            m_Table = new Hashtable();

            Load();
        }

        /// <summary>
        /// Singleton 建構方法。
        /// </summary>
        /// <returns></returns>
        public static ImmPhraseTable GetInstance()
        {
            if (m_ImmPhraseTbl == null)
            {
                m_ImmPhraseTbl = new ImmPhraseTable();
            }
            return m_ImmPhraseTbl;
        }

        #region 載入函式

        /// <summary>
        /// 從組件資源中載入對照表。
        /// </summary>
        public void Load()
        {
            Assembly asmb = Assembly.GetExecutingAssembly();
            Stream stream = asmb.GetManifestResourceStream(ImmPhraseTblResName);
            using (stream)
            {
                using (StreamReader sr = new StreamReader(stream, Encoding.Default))
                {
                    Load(sr);
                }
            }
        }

        /// <summary>
        /// 從串流中讀取對照表。
        /// </summary>
        /// <param name="sr"></param>
        public void Load(StreamReader sr)
        {
            String line;
            string[] fields;
            char[] sep = new char[] { ' ' };
            string phrase;


            while ((line = sr.ReadLine()) != null)
            {
                fields = line.Split(sep, 5, StringSplitOptions.RemoveEmptyEntries);
                if (fields.Length < 2)  // 若只定義中文字，未指定字根，則不處理。
                    continue;

                // 取出中文辭彙。
                phrase = fields[0];

                // 移除既有的項目，亦即後來載入的資料會蓋過之前載入的。
                if (m_Table.ContainsKey(phrase))
                {
                    m_Table.Remove(phrase);
                }
                List<Zhuyin> zyList = new List<Zhuyin>();
                for (int i = 1; i < fields.Length; i++)
                {
                    Zhuyin zy = new Zhuyin(fields[i]);
                    zyList.Add(zy);
                }
                m_Table.Add(phrase, zyList);
            }
        }

        /// <summary>
        /// 從外部檔案載入。
        /// </summary>
        /// <param name="filename"></param>
        public void Load(string filename)
        {
			Encoding enc = Encoding.Default;

			// 根據檔案名稱來判斷編碼.
			if (filename.IndexOf(".big5", StringComparison.CurrentCultureIgnoreCase) >= 0)
			{
				enc = Encoding.GetEncoding(950);
			}
			else if (filename.IndexOf(".utf", StringComparison.CurrentCultureIgnoreCase) >= 0)
			{
				enc = Encoding.UTF8;
			}

			using (StreamReader sr = new StreamReader(filename, enc))
            {
                Load(sr);
				System.Diagnostics.Debug.WriteLine("ImmPhraseTable loaded: " + filename);
            }
        }

        #endregion


        public List<Zhuyin> this[string phrase]
        {
            get
            {
                object value = m_Table[phrase];
                if (value == null)
                    return null;
                return (List<Zhuyin>)value;
            }
        }

        /// <summary>
        /// 清除所有辭彙，只保留系統內建的。
        /// </summary>
        public void Reset()
        {
            m_Table.Clear();
            Load();
        }

        /// <summary>
        /// 傳回指定辭彙對應的注音符號。例如：傳入「什麼」，傳回「ㄕ　ㄜˊ ㄇ　ㄜ˙」。
        /// </summary>
        /// <param name="phrase">中文詞彙。</param>
        /// <returns>注音符號，每個中文字固定傳回四個字元長度的注音符號，其中可能包含全型空白，例如：「ㄕ　ㄜˊ」。</returns>
        public string GetZhyuinSymbols(string phrase)
        {
            object value = m_Table[phrase];
            if (value == null)
            {
                return "";
            }
            List<Zhuyin> zyList = (List<Zhuyin>)value;
            StringBuilder sb = new StringBuilder();
            foreach (Zhuyin zy in zyList) 
            {
                sb.Append(zy.ToString(true));
            }
            return sb.ToString();
        }

        /// <summary>
        /// 找出在指定的字串中出現的所有片語。
        /// </summary>
        /// <param name="text">字串。</param>
        /// <returns>找到的片語集合，它是一個排序過的串列，排序的 key 是片語位於來源字串的的索引，Value 則是 ImmPhrase 型別的物件。</returns>
        public SortedList<int, ImmPhrase> FindPhrases(string text)
        {
            SortedList<int, ImmPhrase> matchedPhrases = new SortedList<int, ImmPhrase>();

            int idx;
            int start;
            int end;
            int count;
            ImmPhrase immPhrase;
            List<Zhuyin> zhuyinList;

            foreach (string phrase in m_Table.Keys)
            {
                start = 0;
                end = text.Length-1;
                while (start <= end)
                {
                    count = end - start + 1;
                    idx = text.IndexOf(phrase, start, count);
                    if (idx < 0)
                        break;
                    // 有找到，記錄位置、取得注音字根，並繼續往後面找。
                    zhuyinList = (List<Zhuyin>) m_Table[phrase];
                    immPhrase = new ImmPhrase(phrase, zhuyinList);
                    matchedPhrases.Add(idx, immPhrase);
                    start = idx + phrase.Length;
                }
            }
            return matchedPhrases;
        }
    }
}

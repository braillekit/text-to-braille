using System;
using System.Collections.Generic;
using System.Text;
using System.Web;

namespace Huanlin.Helpers
{
    public static class WebHelper
    {
        /// <summary>
        /// �Ǧ^���w�� HTTP �ШD���ڵ������|�C
        /// </summary>
        /// <param name="req"></param>
        /// <returns></returns>
		public static string GetRootUrl(HttpRequest req)
		{
			StringBuilder sb = new StringBuilder();
			sb.Append(req.Url.Scheme);
			sb.Append("://");
			sb.Append(req.Url.Authority);
			sb.Append(req.ApplicationPath);
			sb.Append("/");

			return sb.ToString();
		}

		/// <summary>
		/// ���o�Τ�ݪ� IP ��}�C
		/// </summary>
		/// <param name="req">Request ����C</param>
		/// <param name="detectProxy">�O�_���� proxy�C</param>
		/// <returns></returns>
		public static string GetClientIPAddress(HttpRequest req, bool detectProxy)
		{
			string ip = null;

			if (detectProxy)
			{
				ip = req.ServerVariables["HTTP_X_FORWARDED_FOR"];
				if (String.IsNullOrEmpty(ip))
				{
					ip = req.ServerVariables["REMOTE_ADDR"];
				}
			}
			else
			{
				ip = req.ServerVariables["REMOTE_ADDR"];
			}

			return ip;
		}
    }
}

using System;
using System.Collections.Generic;
using System.Text;

namespace Huanlin.Helpers
{
	/// <summary>
	/// ����ɶ��u��禡�C
	/// </summary>
	public static class DateHelper
	{
	}
}

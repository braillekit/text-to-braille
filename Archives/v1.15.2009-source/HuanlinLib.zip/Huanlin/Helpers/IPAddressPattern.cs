using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Net;

namespace Huanlin.Helpers
{
	/// <summary>
	/// �ΨӥN�� IP ��}���˦��A�Ҧp�G192.168.*.*�C
	/// �]�i�H�Ψ��x�s IP ��}�C�Ҧp�G192.168.0.1�C
	/// </summary>
	public class IPAddressPattern
	{
		public string[] m_Parts;

		public IPAddressPattern()
		{
			m_Parts = new string[] { "0", "0", "0", "0" };
		}

		public IPAddressPattern(string pattern) : this()
		{
			char[] sep = new char[] { '.' };
			string[] parts = pattern.Split(sep, 4);

			SetParts(parts);
		}

		public IPAddressPattern(string[] parts) : this()
		{
			SetParts(parts);
		}

		protected void SetParts(string[] parts)
		{
			string errmsg = "�L�Ī� IP ��}�˦�!";

			for (int i = 0; i < 4; i++)
			{
				try
				{
					// ��Ʀr���e�� 0 �h���C
					int k = Convert.ToInt32(parts[i]);
					if (k >= 0 && k <= 255)
					{
						m_Parts[i] = k.ToString();
					}
					else
					{
						throw new ArgumentException(errmsg);
					}
				}
				catch
				{
					if (parts[i] == "*")
					{
						m_Parts[i] = parts[i];
					}
					else
					{
						throw new ArgumentException(errmsg);
					}

				}
			}
		}

		public bool IsValidPart(string s)
		{
			try
			{
				int k = Convert.ToInt32(s);
				return (k >= 0 && k <= 255);
			}
			catch
			{
				return (s == "*");
			}
		}

		public override string ToString()
		{
			StringBuilder sb = new StringBuilder();
			for (int i = 0; i < 4; i++) {
				sb.Append(m_Parts[i]);
				if (i < 3) 
				{
					sb.Append(".");
				}
			}
			return sb.ToString();
		}

		public override int GetHashCode()
		{
			int[] mul = new int[] {1000, 100, 10, 1};
			int value = 0;
			for (int i = 0; i < m_Parts.Length; i++)
			{
				try 
				{
					value += Convert.ToInt32(m_Parts[i]) * mul[i];
				}
				catch 
				{
					value += 256 * mul[i];
				}				
			}
			return value;
		}

		public override bool Equals(object obj)
		{
			IPAddressPattern ipap = (IPAddressPattern)obj;

			if (this == obj)
				return true;
			
			if (obj == null)
				return false;

			for (int i = 0; i < 4; i++)
			{
				if (!this[i].Equals(ipap[i]))
					return false;
			}

			return true;
		}

		/// <summary>
		/// �N�r���R�� IPAddressPattern ����C
		/// </summary>
		/// <param name="input"></param>
		/// <returns></returns>
		public static IPAddressPattern Parse(string s)
		{
			char[] sep = new char[] { '.' };
			string[] parts = s.Split(sep, 4);

			return new IPAddressPattern(parts);
		}

		/// <summary>
		/// �P�_�O�_���X�k�� IP ��}�C
		/// </summary>
		/// <param name="ip">IP ��}</param>
		/// <returns></returns>
		public static bool IsValidIPAddress(string ip)
		{
			string exp = @"^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$";
			return Regex.IsMatch(ip, exp);
		}

		/// <summary>
		/// ���ޤl�C
		/// </summary>
		/// <param name="idx"></param>
		/// <returns></returns>
		public string this[int idx]
		{
			get
			{
				if (idx < 0 || idx > 3)
				{
					throw new IndexOutOfRangeException();
				}
				return m_Parts[idx];
			}

			set
			{
				if (idx < 0 || idx > 3)
				{
					throw new IndexOutOfRangeException();
				}
				if (!IsValidPart(value))
				{
					throw new Exception("���w���Ȥ��O�X�k�� IP ��}!");
				}

				if (value == "*")
				{
					m_Parts[idx] = value;
				}
				else
				{
					m_Parts[idx] = Convert.ToInt32(value).ToString();	// ��Ʀr���e�� 0 �h���C
				}
			}
		}

		/// <summary>
		/// �P�_�Y�� IP ��}�O�_�ŦX���w���˦��C
		/// </summary>
		/// <param name="ip">IP ��}</param>
		/// <returns></returns>
		public bool IsMatch(string ip)
		{
			// ���ˬd�O�_���X�k�� IP ��}�C
			if (!IPAddressPattern.IsValidIPAddress(ip))
			{
				throw new ArgumentException(ip + " ���O�X�k�� IP ��}!");
			}

			IPAddressPattern ipaddr = IPAddressPattern.Parse(ip);
			
			for (int i = 0; i < 4; i++) {
				if (this[i] != "*" && Convert.ToInt32(this[i]) != Convert.ToInt32(ipaddr[i]))
					return false;
			}
			return true;
		}
	}
}

using System;
using System.Collections.Generic;
using System.Text;
using System.Data;

namespace Huanlin.Helpers
{
	/// <summary>
	/// ��ƳB�z�u��禡�C
	/// </summary>
	public static class DbHelper
	{
	}
}
